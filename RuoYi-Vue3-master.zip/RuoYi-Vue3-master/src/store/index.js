const store = createPinia()

export default store