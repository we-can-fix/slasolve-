export interface IChooseRequesterEntity {
  label: string;
  value: string;
}
