# Debug LangBot Frontend

Please refer to the [Development Guide](https://docs.langbot.app/en/develop/dev-config.html) for more information.
