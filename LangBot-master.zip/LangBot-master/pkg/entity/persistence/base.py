import sqlalchemy.orm


class Base(sqlalchemy.orm.DeclarativeBase):
    pass
