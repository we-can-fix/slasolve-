semantic_version = 'v4.4.1'

required_database_version = 9
"""Tag the version of the database schema, used to check if the database needs to be migrated"""

debug_mode = False

edition = 'community'
